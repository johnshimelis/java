/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo;

import java.util.Scanner;
public class NumberGuessGame {
    public static void main(String[] args){
        GuessGames game = new GuessGames();
       int numOfGuess = 0;
       
        int secretNumber = (int) (Math.random() *100);
         System.out.println(secretNumber);
               
        while(numOfGuess < 7){
            numOfGuess++;
        int played = numOfGuess;
       int keri = 7 - numOfGuess;
    
   
           
            System.out.println("*********************************");
         
        System.out.println("Enter Your Guess From 0 to 100 Here :");
     
        Scanner scan = new Scanner(System.in);
        int guess = scan.nextInt();
        int[] tooCloseAbove = {secretNumber +1,secretNumber+2,secretNumber+3,secretNumber+4,secretNumber+5};
        int[] tooCloseBelow =  {secretNumber -1,secretNumber-2,secretNumber-3,secretNumber-4,secretNumber-5};
         game.setCloseAbove(tooCloseAbove);
        game.setCloseBelow(tooCloseBelow);
         String result = "Sorry Game Over! You Finished your trail";
            
    
        if(guess == secretNumber){
             System.out.println("*********************************");
            System.out.println("Congratulation You Get The Number Correctly!!!");
            System.out.println("You Got The Number In The : " + numOfGuess + " Round!!!");
        
           
            System.out.println("Do You Want To Play Again ? [Yes/No]");
       
             //System.out.println(secretNumber);
           Scanner input = new Scanner(System.in);
            String yes = input.nextLine();
            if(yes.equalsIgnoreCase("YES")){
                 numOfGuess = 1;
                  keri = 7 - numOfGuess;
                secretNumber = (int) (Math.random() *100);
                    
                System.out.println("Enter Your Guess From 0 to 100 Here :");
                guess = input.nextInt();
                
               
            }
            else if(yes!="Yes"){
            break;
            }
            
             
            
     
    }
        for(int guessAbove : tooCloseAbove){
            if(guess == guessAbove){
                 System.out.println("*********************************");
                System.out.println("Your Are Much Closer To The Number Above. Guess a little Below");
                    System.out.println("You Have Played :" + numOfGuess + " Rounds And You Left :" + keri + " Chances" );
               
            }
        }
        for(int guessBelow : tooCloseBelow){
            if(guess == guessBelow){
                 System.out.println("*********************************");
                System.out.println("Your Are Much Closer To The Number Below. Guess a little Above");
                    System.out.println("You Have Played :" + numOfGuess + " Rounds And You Left :" + keri + " Chances" );
            }
        }
         if(guess < secretNumber-5){
              System.out.println("*********************************");
                System.out.println("Your Guess Is Too Low!!!");
                 System.out.println("You Have Played :" + numOfGuess + " Rounds And You Left :" + keri + " Chances" );
                }
         else if(guess > secretNumber+5){
              System.out.println("*********************************");
             System.out.println("Your Guess Is Too High!!!");
                System.out.println("You Have Played :" + numOfGuess + " Rounds And You Left :" + keri + " Chances" );
         }
        
         
          if(numOfGuess > 6){
         System.out.println("*********************************");
        System.out.println("Sorry Game Over! You Finished your trail");
        System.out.println("The Secret Number Was : " + secretNumber);
        System.out.println("Do You Want To Retry Again ? [Yes/No]");
        Scanner no = new Scanner(System.in);
        String input = no.nextLine();
        if(input.equalsIgnoreCase("Yes")){
              numOfGuess = 1;
              keri = 7-numOfGuess;
               
             System.out.println("Enter Your Guess From 0 to 100 Here :");
                    guess = no.nextInt();
                     System.out.println("You Have Played :" + numOfGuess + " Rounds And You Left :" + keri + " Chances" );
           
        }
        else{
           
   }
     
        }
    
    }
        
    }}

class GuessGames{
    int[] closeAbove;
    int[] closeBelow;
    
    public void setCloseAbove(int[] above){
        closeAbove = above;
    }
    public void setCloseBelow(int[] below){
        closeBelow = below;
    }
}

