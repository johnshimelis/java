    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo;


public class Output {
    public static void main(String[] args){
        Output out = new Output();
        out.go();
    }
    public void go(){
        int y = 7;
        for(int x = 1; x < 8; x++){
            y++;
            
            if(x > 4){
                System.out.print( ++y + " ");
        }
            if(y > 14){
                System.out.print(" x = " + x);
                   break;
            }
     
    }
    
}
}