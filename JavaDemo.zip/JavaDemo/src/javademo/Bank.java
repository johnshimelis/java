/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo;
import java.util.Scanner;
public class Bank {
    public static int amount = 0;
    public static void open(String s, int n){
        System.out.println("Dear Customer Enter Your Name Here:");
        Scanner scan = new Scanner(System.in);
        String name = scan.nextLine();
        
        System.out.println("Dear Customer Enter The Intital Amount here :");
        Scanner input = new Scanner(System.in);
        Bank.amount = input.nextInt();
        System.out.println("Dear Customer Your Name : " + name);
        System.out.println("Dear Customer Your Current Balance : " + amount);
        
    }
    public static void deposit(String s, int n){
        System.out.println("Dear Customer Enter the amount to be deposit :");
        Scanner in = new Scanner(System.in);
        int dep = in.nextInt();
        Bank.amount = amount + dep;
        System.out.println("Dear Customer You Deposit :" + dep);
        System.out.println("Dear Customer Your Current Balance : " + amount);
    }
    public static void withdraw(String s, int n){
        System.out.println("Dear Customer Enter The Amount To Be Withdraw : ");
        Scanner in1 = new Scanner(System.in);
        int withdraw = in1.nextInt();
        if(Bank.amount < withdraw){
            System.out.println("Dear Customer Your Account Balance is insufficent for this service");
            System.out.println("Dear Customer Your Current Balance is : " + Bank.amount + " birr only. So You can not withdraw : " + withdraw + " birr right  now");
        }
        else if(Bank.amount == withdraw){
            System.out.println("Dear Customer You have to leave some amount in your account. so you can not withdraw : " + withdraw + " birr from : " + Bank.amount + " birr . Please Decrease some amount of withdraw");
        }
        else{
        Bank.amount = amount - withdraw;
        System.out.println("Dear Customer You Withdraw : " + withdraw);
        System.out.println("Dear Customer Your Current Balance : " + amount);
        
    }
    }
    public static void check(String s, int n){
        System.out.println("Dear Customer Your Current Balance is : " + Bank.amount);
    }
    public static void close(String s , int n){
        System.out.println(" Dear Customer Your Current Balance is 0");
        Bank.amount = 0;
    }        
    
    
    public static void main(String[] args){
        System.out.println("Dear Customer Welcome To Our Banking System . Thanks For Chossing Us !!!");
        System.out.println("***********************");
        System.out.println("1. Open Account");
        System.out.println("2. Deposite");
        System.out.println("3, Withdraw");
        System.out.println("4. Check Balance");
        System.out.println("5. Close Account");
        System.out.println("***********************");
        
        System.out.println("Enter Your Choice Of Tasks :");
        Scanner scan = new Scanner(System.in);
        int choice = scan.nextInt();
        
        String s = new String();
        int n = 0;
        switch(choice){
            case 1 : open(s,n);
            break;
            case 2 : deposit(s,n);
            break;
            case 3 : withdraw(s,n);
            break;  
            case 4 : check(s,n);
            break;
            case 5 : close(s,n);
            break;
            default : System.out.println("You Entered Wrong Choice!!!");
            break;
        }
        System.out.println("Press 6 to continue : ");
        Scanner input = new Scanner(System.in);
        int cont = input.nextInt();
        if(cont == 6){
            String[] s2 = null;
            main(s2);
    }
}
}
