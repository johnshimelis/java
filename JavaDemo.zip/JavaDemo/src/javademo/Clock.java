/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo;

public class Clock {
    String time;
    
    void setTime(String t){
        time = t;
    }
    String getTime(){
        return time;
    }
    
}
class ClockTestDrive{
    public static void main(String[] args){
        Clock clock = new Clock();
        clock.setTime("2345");
        String timer = clock.getTime();
        System.out.println("The time is : " + timer);
    }
}
