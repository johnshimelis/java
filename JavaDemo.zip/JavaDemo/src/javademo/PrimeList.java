/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo;


public class PrimeList {
    public static void main(String[] args){
        for(int i = 1; i<20; i++){
          int f = 0;
          for(int j = 2; j <= i-1; j++){
              if(i%j==0){
                  f = f + 1;
              }
          }
          if(f == 0){
              System.out.println("Prime no." + i);
        }
    }
    
}
}
