
package javademo;

import java.util.ArrayList;
import java.util.Scanner;
public class SimpleDotComGame {
    
    private ArrayList<String>  locationCells;
    private int numOfHits = 0;
    int[] guesses;
    public void setGuesses(int[] input){
        guesses = input;
    }
    
    public void setLocationCells(ArrayList<String> locs){
        locationCells = locs;
    } 
   public String checkYourself(String stringGuess){
        int guess = Integer.parseInt(stringGuess);
        String result = "miss";
        int index = locationCells.indexOf(guess);
        if(index >= 0){
            locationCells.remove(index);
            
            if(locationCells.isEmpty()){
                result = "Kill";
              }
            else{
                result = "Hit";
                }
               
            }
     
       
        return result;
   }
}
class SimpleDotComTestDrive{
    public static void main(String[] args){
        int numOfGuesses = 0;
       // GameHelper helper = new GameHelper();
        SimpleDotComGame  dot = new SimpleDotComGame();
        int randomNum = (int) (Math.random() * 5);
       // System.out.println(randomNum);
        int[] location = {randomNum, randomNum + 1, randomNum + 2};
        
        dot.setLocationCells(location);
        boolean isAlive = true;
        
        while(isAlive == true){
            Scanner scan = new Scanner(System.in);
             System.out.println("Enter Your Guess Here :");
            String guess = scan.nextLine();
            int input = Integer.parseInt(guess);
            int[] guesses = {input};
            dot.setGuesses(guesses);
            String result = dot.checkYourself(guess);
            numOfGuesses++;
              
            if(result.equals("kill")){
                isAlive = false;
                System.out.println("You took : " + numOfGuesses + " guesses" );
            }
            
      
    }
        
}}
