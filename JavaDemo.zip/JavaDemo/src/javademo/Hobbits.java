/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo;

public class Hobbits {
    String name;
    public static void main(String[] args){
        
        Hobbits[] hoo = new Hobbits[3];
         
        int x = 0;
        while(x < 4){
           
            hoo[x] = new Hobbits();
            hoo[x].name = "bilbo";
            
            if(x == 1){
                hoo[x].name = "frodo";
               
            }
            if(x == 2){
                hoo[x].name = "sam";
            }
            System.out.println(hoo[x].name + " : is a good hobbit name");
             x = x + 1;
        }
    }
    
}
