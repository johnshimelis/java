
package javademo;

public class Triangle {
    double area;
    int lenght;
    int height;
    
}
