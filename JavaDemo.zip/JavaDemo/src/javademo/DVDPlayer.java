/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo;


public class DVDPlayer {
    
    boolean canRecord = false;
    
    public void recordDVD(){
        System.out.println("The DVD Player is Recording");
    }
    public void playDVD(){
        System.out.println("The DVD Player is Playing");
    }
    
}
class DVDPlayerTestDriver{
    public static void main(String[] args){
        DVDPlayer player = new DVDPlayer();
        player.canRecord = true;
        player.playDVD();
        
        
        if(player.canRecord == true){
            player.recordDVD();
    }
}
}

