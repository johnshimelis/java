
package javademo;
import java.util.Scanner;

public class GuessGame {
    Player p1;
    Player p2;
    Player p3;
    int counter = 0;
    public void startGame(){
        p1 = new Player();
        p2 = new Player();
        p3 = new Player();
        
        int guessp1 = 0;
        int guessp2 = 0;
        int guessp3 = 0;
        
        boolean p1isRight = false;
        boolean p2isRight = false;
        boolean p3isRight = false;
        
        int targetNumber = (int) (Math.random()*10);
          System.out.println("*******************************************");
        System.out.println("I am thinking of a number between 0 and 9...");
while(true){
        System.out.println("Number to guess is " + targetNumber);
          System.out.println("*******************************************");
       
     System.out.println("Player one please enter your guess here : ");
     p1.guess();
     System.out.println("Plyer two please enter your guess here : ");
     p2.guess();
     System.out.println("Player three please enter your guess here : ");
     p3.guess();
     System.out.println("");
     counter++;
       System.out.println("*******************************************");
        guessp1 = p1.num1;
        System.out.println("Player one guessed " + guessp1);
        
        guessp2 = p2.num1;
        System.out.println("Player two guessed " + guessp2);
        
        guessp3 = p3.num1;
        System.out.println("Player three guessed " + guessp3);
          System.out.println("*******************************************");
        System.out.println("");
        
        if(guessp1 == targetNumber){
            p1isRight = true;
        }
        if(guessp2 == targetNumber){
            p2isRight = true;
        }
        if(guessp3 == targetNumber){
            p3isRight = true;
        }
        
        if(p1isRight || p2isRight || p3isRight){
            System.out.println("*******************************************");
            System.out.println("Game is over.");
            System.out.println("We have a winner!");
            System.out.println("Player one got it right?" + p1isRight);
            System.out.println("Player two got it right?" + p2isRight);
            System.out.println("Player three got it right?" + p3isRight);
              System.out.println("*******************************************");
            
            counter = 0;
              System.out.println("*******************************************");
            System.out.println("Do you want to play the game again?");
            Scanner scan = new Scanner(System.in);
            String str = scan.nextLine();
            if(str.equalsIgnoreCase("YES")){
                startGame();
                  System.out.println("*******************************************");
            }
            else{
                break;
            }
          
            
        }
        else{
            int num = 3 - counter;
              System.out.println("*******************************************");
            System.out.println("Player will have to try again");
            System.out.println("You Have Played : " + counter + " Times And You Left : " + num + " Chances");
              System.out.println("*******************************************");
            System.out.println("");
            if(counter >=3){
                    counter = 0;
                  System.out.println("*******************************************");
           System.out.println("Time is Up. Please Try Later");
        System.out.println("");
        System.out.println("Do you want to Retry?");
          System.out.println("*******************************************");
        Scanner scan = new Scanner(System.in);
        String retry = scan.nextLine();
        
        if(retry.equalsIgnoreCase("YES")){
            startGame();
        }
        else{
            
        }  
        }
}
       
  }
    }
}
    
    
