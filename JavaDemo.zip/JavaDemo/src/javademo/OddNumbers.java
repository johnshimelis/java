/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo;

//print all odd numbers up to 20
public class OddNumbers {
        public static void main(String[] args){
            int a = 0;
            for(int i = 0; i <= 20; i++){
                if(i % 2 !=0){
                    System.out.println(i);
                }
                
            }

}
}
    

