/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo;

/**
 *
 * @author John
 */
public class BeerSong {
    public static void main(String[] args){
        int beerNum = 99;
        String name = "bottles";
        
        while(beerNum >0){
            
            if(beerNum == 1){
                name = "bottle";
            }
            
                System.out.println(beerNum +  " " + name + " of beer on the wall" );
                System.out.println(beerNum + " " + name + " of beer");
                System.out.println("Take one down");
                System.out.println("Pass it around");
                beerNum--;
                
                if(beerNum <= 0){    
                    System.out.println("No more bottle of beer on the wall");
                }
             
            }
    
}
}
