/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo;
import java.util.Scanner;
public class Calculator {
    public static int add(int a, int b){
        int c = a+b;
        return c;
    }
    public static int sub(int a,int b){
        int c = a - b;
        return c;
    }
    public static int mul(int a, int b){
        int c = a * b;
        return c;
    }
    public static int div(int a, int b){
        int c = a / b;
        return c;
    }
    public static int mod(int a, int b){
        int c = a % b;
        return c;
    }
    public static void main(String[] args){
        System.out.println("**Options for our Calclator**");
        System.out.println("1--> (+) Addition (+)");
        System.out.println("2--> (-) Substract (-)");
        System.out.println("3--> (*) Multiply (*)");
        System.out.println("4--> (/) Divide (/)");
        System.out.println("5--> (%) Modulo (%)");
        
        System.out.println("*** Give First No *** :-->");
        Scanner scan = new Scanner(System.in);
        int firstNum = scan.nextInt();
        
        System.out.println("*** Give Second No *** :-->");
        int secondNum = scan.nextInt();
        
        System.out.println("*** Enter Your Choice Here *** :-->");
        int choice = scan.nextInt();
        
        int z = 0;
        switch(choice){
            case 1 : z = add(firstNum,secondNum);
            break;
            case 2 : z = sub(firstNum,secondNum);
            break;
            case 3 : z = mul(firstNum,secondNum);
            break;
            case 4 : z = div(firstNum,secondNum);
            break;
            case 5 : z = mod(firstNum,secondNum);
            break;
            default: System.out.println("You Entered Wrong Choice!!!");
            break;
         }
        System.out.println("*** result *** :-->");
        System.out.println(z);
        
        System.out.println("*** Press 6 to continue *** :-->");
        Scanner input = new Scanner(System.in);
        int cont = input.nextInt();
        
        if(cont == 6){
            String[] s = null;
            main(s);
        }
        
        
    }
    
    
}
