/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo;
import java.util.Scanner;
public class StringPalindrome {
    public static void main(String[] args){
        while(true){
        System.out.println("Please enter any string here : ");
        Scanner scan = new Scanner(System.in);
        String str = scan.nextLine();
        String s1 = new String();
        
        int n = str.length();
        for(int i = n-1; i>=0; i--){
            char chr = str.charAt(i);
            s1 = s1 + chr;
        }
            if(s1.equalsIgnoreCase(str)){
                System.out.println("The given string is palindrome");
            }
            else{
                System.out.println("The given string is not palindorme");
            }
}}}


