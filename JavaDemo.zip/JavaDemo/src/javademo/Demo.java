/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo;

/**
 *
 * @author John
 */
public class Demo {
    public static void main(String[] args){
        int x = 1;
        while(x < 3){
            System.out.print("Doo");
            System.out.print("Bee");
            x++;
}
    
        if(x==3){
            System.out.print("Do");
    }
    }
}
