/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo;

public class Books {
    String title;
    String author;
    
}
class BooksTestDrive{
    public static void main(String[] args){
        //Books books = new Books();
        Books[] myBooks = new Books[3];
        
        myBooks[0] = new Books();
        myBooks[1] = new Books();
        myBooks[2] = new Books();
        
        myBooks[0].title = "HeadFirst For Java";
        myBooks[1].title = "Proffessionals Note";
        myBooks[2].title = "Certified For Beginners";
        myBooks[0].author = "John";
        myBooks[1].author = "Bob";
        myBooks[2].author = "Sue";
        
        int x = 0;
        while(x < myBooks.length){
            System.out.print(myBooks[x].title );
            System.out.print(" By ");
            System.out.println( myBooks[x].author);
            x++;
        }
        
        
    }
}
