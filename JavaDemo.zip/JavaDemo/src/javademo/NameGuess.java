
package javademo;
import java.util.Scanner;

public class NameGuess {
    public static void main(String[] args){
        
        Names name = new Names();
       name.Names();
   
    }
}