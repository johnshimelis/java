/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo;

import java.util.Scanner;
public class PerfectNo {
    
   public static void main(String[] args){
       while(true){
       System.out.println("Please enter any number here : ");
       Scanner scan  = new Scanner(System.in);
       int num= scan.nextInt();
       
       int s = 0;
       for(int i = 1; i < num; i++){
           if(num%i == 0){
               s = s + i;
           }
       }
       if (num == s){
           System.out.println("The given number is perfect number");
       }
       else{
           System.out.println("The given number is not a perfect number");
       }
   }
}
}
