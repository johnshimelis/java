
package javademo;
import java.util.Scanner;

public class Names {

    String fullName;

    
    public void Names(){
     
       System.out.println("Are You Ready To See The Guess? [Yes or No]");
           Scanner scan = new Scanner(System.in);
      String str = scan.nextLine();
        if(str.equalsIgnoreCase("YES")){
                    String[] firstName = {"John","Yohannes","Belay","Debra","Mamo","Soyam","Mimi","Fiker","Kaleb","Amir","Indiris","Shimelis","Taddess"} ;
        String[] lastName = {"Shimelis","Assebe","Minase","Nimani","Mustafa","Yasin","Tizazu"}; 
        
      
     int firstLength = firstName.length;
     int lastLength = lastName.length;
           System.out.println("Possible Candidates of First Names :");
           System.out.println("*****************************************");
     for(int i=0; i<firstLength;i++){
         System.out.println(firstName[i]);
     }
           System.out.println("Possible Candidates of Last Names :");
           System.out.println("*****************************************");
     for(int j=0; j<lastLength;j++){
         System.out.println(lastName[j]);
     }
     
            nameMethod();
        }
    }
       public void nameMethod(){
            String[] firstName = {"John","Yohannes","Belay","Debra","Mamo","Soyam","Mimi","Fiker","Kaleb","Amir","Indiris","Shimelis","Taddess"} ;
        String[] lastName = {"Shimelis","Assebe","Minase","Nimani","Mustafa","Yasin","Tizazu"}; 
        
      
     int firstLength = firstName.length;
     int lastLength = lastName.length;
  
     
     int firstRand = (int)(Math.random() * firstLength);
     int lastRand =  (int)(Math.random() * lastLength);
     
      fullName = firstName[firstRand] + " " + lastName[lastRand];
        Scanner scan = new Scanner(System.in);
            System.out.println("Please Enter Your Guess Here : ");
            String guess = scan.nextLine();
          
            if(guess.equals(fullName)){
                System.out.println("Congra you got it!!!");
            }
            else{
                System.out.println("Oooops you lose!!!");
        }
        System.out.println("What we need is : " + fullName);
        
     
       
        
       System.out.println("Do You Want Guess Again? [Yes or No]");
         Scanner input = new Scanner(System.in);
        String string = input.nextLine();
        if(string.equalsIgnoreCase("YES")){
            nameMethod();
        }
        
        
        else{
            
        }
        }

}
    
