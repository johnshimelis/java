/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo;


public class Fibonacci {
    public static void main(String[] args){
        int a = 0;
        System.out.println(a);
        int b = 1;
        for(int i = 0; i<=5;i++){
            b = a+b;
            a = a+b;
            System.out.println(b);
            System.out.println(a);
        }
    }
}
