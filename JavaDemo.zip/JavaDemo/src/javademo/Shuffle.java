/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo;

/**
 *
 * @author John
 */
public class Shuffle {
    
    public static void main(String[] args){
        int x = 0;
        while(x < 4){
            System.out.print("a");
            if(x < 1){
                System.out.print(" ");
               }
             System.out.print("n");
            if(x == 1){
                System.out.println("noys");
              }
            if(x > 1){
                System.out.print(" ");
                System.out.println("oyster");
                x = x + 2;
            }
            if(x < 1){
               System.out.print("oise");
            }
           System.out.println("");
            x++;
            
        }
}
}
