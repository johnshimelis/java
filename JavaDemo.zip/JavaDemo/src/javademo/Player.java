
package javademo;
import java.util.Scanner;

public class Player {
    
    int num1 =0;
       
    public void guess(){
        Scanner in = new Scanner(System.in);
        
        num1  = in.nextInt();
        System.out.println("I am guessing "+ num1);
          System.out.println("*******************************************");
        

}
}
