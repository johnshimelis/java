/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo;
import java.util.Scanner;


public class Armstrong {
    public static void main(String[] args){
        while(true){
        System.out.println("Give any 3 digit No");
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        
        int a = n/100;
        int A = n%100;
        
        int b = A/10;
        int c = A%10;
        
        int x = a*a*a+b*b*b+c*c*c;
        if(n==x){
            System.out.println("Given No is armstrong");
        }
        else{
            System.out.println("The given No is not armstrong");
        }
        
        }  
    }
    
}
