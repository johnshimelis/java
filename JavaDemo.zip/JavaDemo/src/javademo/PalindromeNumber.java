/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo;

import java.util.Scanner;
public class PalindromeNumber {
    public static void main(String[] args){
        System.out.println("Please Enter Number Not More Than 4 Digits : ");
        Scanner scan = new Scanner(System.in);
        int num = scan.nextInt();
        int A = num/10;
        int a = num%10;
        int B = A/10;
        int b = A%10;
        int C = B/10;
        int c = B%10;
        
        int x = a*1000 + b*100 + c*10 + C;
        if(num == x){
            System.out.println("The Given Number Is Palindrome");
        }
        else{
            System.out.println("The Given Number is Not Palindrome");
        }
        
        
        
    }
    
}
